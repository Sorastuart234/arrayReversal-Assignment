class Main {
  public static void main(String[] args) {
    int[] array = new int[] {4,8,1,-2,3};
    int[] reverse = arrayReversal(array);
  for(int i = 0; i < array.length; i++){
    System.out.print(reverse[i] + " ");
    }
  }

public static int[] arrayReversal(int[] arr){
  int[] reverse = new int[arr.length];
  int index1 = arr.length - 1;
  for(int i = 0; i < arr.length; i++){
    reverse[i] = arr[index1];
    index1 = index1 - 1;
  }
  return reverse;
}
  
}




